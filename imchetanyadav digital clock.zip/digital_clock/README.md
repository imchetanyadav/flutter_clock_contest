# Digital Clock

This app is an example of a digital clock.
It has a light/dark theme and animated backgrounds based on weather.

<img src='digital_dark.PNG' width='350'>

<img src='digital_light.PNG' width='350'>
